# StaffCore
Original staff plugin for Paper/Spigot 1.20+ (Java 17).

Build: `mvn package` -> target/StaffCore-1.0.0.jar -> put it in /plugins.

Commands: /staff, /vanish, /sc [msg], /freeze <p>, /examine <p>, /report <p> <reason>,
/reports [list|delete <id>|clear], /stafflist, /staffcore reload
Permissions: see plugin.yml. Everything user-facing is editable in config.yml.
