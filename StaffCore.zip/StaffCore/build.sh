#!/bin/sh
mvn package
