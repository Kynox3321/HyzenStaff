package dev.staffcore;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StaffCore extends JavaPlugin {

    private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");

    public final Set<UUID> staffMode = new HashSet<>();
    public final Set<UUID> vanished = new HashSet<>();
    public final Set<UUID> frozen = new HashSet<>();
    public final Set<UUID> chatToggle = new HashSet<>();

    private final Map<UUID, ItemStack[]> savedInv = new HashMap<>();
    private final Map<UUID, GameMode> savedMode = new HashMap<>();
    private final Map<UUID, Boolean> savedFly = new HashMap<>();
    private final Set<UUID> vanishedByStaffMode = new HashSet<>();

    private NamespacedKey actionKey;
    private File reportFile;
    private YamlConfiguration reportData;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        actionKey = new NamespacedKey(this, "action");
        reportFile = new File(getDataFolder(), "reports.yml");
        reportData = YamlConfiguration.loadConfiguration(reportFile);

        getServer().getPluginManager().registerEvents(new StaffListener(this), this);
        StaffCommands cmds = new StaffCommands(this);
        for (String name : getDescription().getCommands().keySet()) {
            if (getCommand(name) != null) {
                getCommand(name).setExecutor(cmds);
                getCommand(name).setTabCompleter(cmds);
            }
        }
    }

    @Override
    public void onDisable() {
        for (UUID id : new HashSet<>(staffMode)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) exitStaff(p, false);
        }
    }

    // ---------- text helpers ----------

    public String color(String s) {
        Matcher m = HEX.matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            StringBuilder r = new StringBuilder("\u00A7x");
            for (char c : m.group(1).toCharArray()) r.append('\u00A7').append(c);
            m.appendReplacement(sb, r.toString());
        }
        m.appendTail(sb);
        return ChatColor.translateAlternateColorCodes('&', sb.toString());
    }

    public String msg(String key, String... kv) {
        String s = getConfig().getString("messages." + key, "&cMissing message: " + key);
        s = s.replace("%prefix%", getConfig().getString("messages.prefix", ""));
        for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace(kv[i], kv[i + 1]);
        return color(s);
    }

    public void notifyStaff(String perm, String message) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission(perm)) p.sendMessage(message);
        }
    }

    // ---------- staff mode ----------

    public void enterStaff(Player p) {
        UUID id = p.getUniqueId();
        ItemStack[] contents = p.getInventory().getContents();
        ItemStack[] copy = new ItemStack[contents.length];
        for (int i = 0; i < contents.length; i++) {
            copy[i] = contents[i] == null ? null : contents[i].clone();
        }
        savedInv.put(id, copy);
        savedMode.put(id, p.getGameMode());
        savedFly.put(id, p.getAllowFlight());

        p.getInventory().clear();
        staffMode.add(id);
        giveItems(p);

        if (getConfig().getBoolean("staff-mode.allow-flight", true)) p.setAllowFlight(true);
        if (getConfig().getBoolean("staff-mode.vanish-on-enter", true) && !vanished.contains(id)) {
            setVanish(p, true);
            vanishedByStaffMode.add(id);
        }
        p.sendMessage(msg("staff-on"));
    }

    public void exitStaff(Player p, boolean notify) {
        UUID id = p.getUniqueId();
        if (!staffMode.remove(id)) return;

        p.getInventory().clear();
        ItemStack[] saved = savedInv.remove(id);
        if (saved != null) p.getInventory().setContents(saved);

        GameMode gm = savedMode.remove(id);
        if (gm != null) p.setGameMode(gm);
        Boolean fly = savedFly.remove(id);
        if (fly != null) {
            p.setAllowFlight(fly || p.getGameMode() == GameMode.CREATIVE);
            if (!fly) p.setFlying(false);
        }
        if (vanishedByStaffMode.remove(id)) setVanish(p, false);
        if (notify) p.sendMessage(msg("staff-off"));
    }

    private void giveItems(Player p) {
        ConfigurationSection items = getConfig().getConfigurationSection("items");
        if (items == null) return;
        for (String action : items.getKeys(false)) {
            ConfigurationSection s = items.getConfigurationSection(action);
            if (s == null || !s.getBoolean("enabled", true)) continue;
            Material m = Material.matchMaterial(s.getString("material", "STONE"));
            if (m == null) continue;
            ItemStack it = new ItemStack(m);
            ItemMeta im = it.getItemMeta();
            im.setDisplayName(color(s.getString("name", action)));
            List<String> lore = new ArrayList<>();
            for (String l : s.getStringList("lore")) lore.add(color(l));
            im.setLore(lore);
            im.getPersistentDataContainer().set(actionKey, PersistentDataType.STRING, action);
            it.setItemMeta(im);
            p.getInventory().setItem(s.getInt("slot", 0), it);
        }
    }

    public String actionOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(actionKey, PersistentDataType.STRING);
    }

    // ---------- vanish ----------

    public void setVanish(Player p, boolean on) {
        UUID id = p.getUniqueId();
        if (on) {
            vanished.add(id);
            for (Player o : Bukkit.getOnlinePlayers()) {
                if (!o.equals(p) && !o.hasPermission("staffcore.vanish.see")) o.hidePlayer(this, p);
            }
        } else {
            vanished.remove(id);
            vanishedByStaffMode.remove(id);
            for (Player o : Bukkit.getOnlinePlayers()) o.showPlayer(this, p);
        }
    }

    public void hideVanishedFrom(Player viewer) {
        if (viewer.hasPermission("staffcore.vanish.see")) return;
        for (UUID id : vanished) {
            Player v = Bukkit.getPlayer(id);
            if (v != null) viewer.hidePlayer(this, v);
        }
    }

    // ---------- staff chat ----------

    public void staffChat(Player from, String message) {
        String out = msg("staffchat-format", "%player%", from.getName(), "%message%", message);
        notifyStaff("staffcore.staffchat", out);
        getLogger().info(ChatColor.stripColor(out));
    }

    // ---------- freeze ----------

    public void toggleFreeze(CommandSender staff, Player target) {
        UUID id = target.getUniqueId();
        if (target.hasPermission("staffcore.freeze.exempt") && !frozen.contains(id)) {
            staff.sendMessage(msg("freeze-exempt"));
            return;
        }
        if (frozen.remove(id)) {
            target.sendMessage(msg("unfreeze-target"));
            staff.sendMessage(msg("unfreeze-staff", "%target%", target.getName()));
        } else {
            frozen.add(id);
            target.sendMessage(msg("freeze-target"));
            target.sendTitle(color("&c&lFROZEN"), color("&7Do not log out"), 5, 100, 10);
            staff.sendMessage(msg("freeze-staff", "%target%", target.getName()));
        }
    }

    // ---------- examine ----------

    public void openExamine(Player viewer, Player target) {
        ExamineHolder holder = new ExamineHolder(target.getUniqueId());
        Inventory inv = Bukkit.createInventory(holder, 45, msg("examine-title", "%player%", target.getName()));
        holder.setInventory(inv);
        ItemStack[] c = target.getInventory().getContents();
        for (int i = 0; i < c.length && i < 41; i++) inv.setItem(i, c[i]);
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 41; i < 45; i++) inv.setItem(i, filler);
        viewer.openInventory(inv);
    }

    // ---------- random tp ----------

    public void randomTp(Player staff) {
        List<Player> pool = new ArrayList<>();
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (!o.equals(staff) && !staffMode.contains(o.getUniqueId()) && !vanished.contains(o.getUniqueId())) pool.add(o);
        }
        if (pool.isEmpty()) {
            staff.sendMessage(msg("random-tp-none"));
            return;
        }
        Player t = pool.get(new Random().nextInt(pool.size()));
        staff.teleport(t.getLocation());
        staff.sendMessage(msg("random-tp", "%player%", t.getName()));
    }

    // ---------- reports ----------

    public int addReport(String reporter, String target, String reason) {
        int id = reportData.getInt("next-id", 1);
        reportData.set("next-id", id + 1);
        String path = "reports." + id;
        reportData.set(path + ".reporter", reporter);
        reportData.set(path + ".target", target);
        reportData.set(path + ".reason", reason);
        reportData.set(path + ".time", System.currentTimeMillis());
        saveReports();
        return id;
    }

    public ConfigurationSection getReports() {
        return reportData.getConfigurationSection("reports");
    }

    public boolean deleteReport(String id) {
        if (!reportData.contains("reports." + id)) return false;
        reportData.set("reports." + id, null);
        saveReports();
        return true;
    }

    public void clearReports() {
        reportData.set("reports", null);
        saveReports();
    }

    public YamlConfiguration reportData() {
        return reportData;
    }

    private void saveReports() {
        try {
            reportData.save(reportFile);
        } catch (IOException e) {
            getLogger().warning("Could not save reports.yml: " + e.getMessage());
        }
    }
}
