package dev.staffcore;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class StaffListener implements Listener {

    private final StaffCore pl;

    public StaffListener(StaffCore pl) {
        this.pl = pl;
    }

    private boolean inStaff(Player p) {
        return pl.staffMode.contains(p.getUniqueId());
    }

    private boolean locked(Player p) {
        return inStaff(p) && !p.hasPermission("staffcore.staffmode.interact");
    }

    // ----- staff items -----

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || e.getAction() == Action.PHYSICAL) return;
        Player p = e.getPlayer();
        if (!inStaff(p)) return;
        String action = pl.actionOf(e.getItem());
        if (action == null) return;
        e.setCancelled(true);

        switch (action) {
            case "vanish" -> {
                boolean on = !pl.vanished.contains(p.getUniqueId());
                pl.setVanish(p, on);
                p.sendMessage(pl.msg(on ? "vanish-on" : "vanish-off"));
            }
            case "random-tp" -> pl.randomTp(p);
            case "fly" -> {
                boolean on = !p.getAllowFlight();
                p.setAllowFlight(on);
                if (!on) p.setFlying(false);
                p.sendMessage(pl.msg(on ? "fly-on" : "fly-off"));
            }
            default -> { }
        }
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (!inStaff(p) || !(e.getRightClicked() instanceof Player target)) return;
        String action = pl.actionOf(p.getInventory().getItemInMainHand());
        if (action == null) return;
        e.setCancelled(true);

        if (action.equals("freeze") && p.hasPermission("staffcore.freeze")) {
            pl.toggleFreeze(p, target);
        } else if (action.equals("examine") && p.hasPermission("staffcore.examine")) {
            pl.openExamine(p, target);
        }
    }

    // ----- staff mode protection -----

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && inStaff(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p
                && (inStaff(p) || pl.frozen.contains(p.getUniqueId()))) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onTarget(EntityTargetEvent e) {
        if (e.getTarget() instanceof Player p
                && (inStaff(p) || pl.vanished.contains(p.getUniqueId()))) e.setCancelled(true);
    }

    // ----- inventories -----

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory top = e.getView().getTopInventory();
        if (top.getHolder() instanceof ExamineHolder) {
            if (!p.hasPermission("staffcore.examine.edit") || e.getRawSlot() >= 41 && e.getRawSlot() < 45) {
                e.setCancelled(true);
            }
            return;
        }
        if (locked(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof ExamineHolder h)) return;
        if (!e.getPlayer().hasPermission("staffcore.examine.edit")) return;
        Player target = Bukkit.getPlayer(h.target);
        if (target == null) return;
        ItemStack[] c = e.getInventory().getContents();
        target.getInventory().setContents(Arrays.copyOf(c, 41));
    }

    // ----- freeze -----

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!pl.frozen.contains(e.getPlayer().getUniqueId())) return;
        Location from = e.getFrom(), to = e.getTo();
        if (to == null) return;
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            Location back = from.clone();
            back.setYaw(to.getYaw());
            back.setPitch(to.getPitch());
            e.setTo(back);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!pl.frozen.contains(p.getUniqueId())) return;
        String cmd = e.getMessage().substring(1).split(" ")[0].toLowerCase();
        List<String> allowed = pl.getConfig().getStringList("freeze.allowed-commands");
        if (allowed.stream().noneMatch(a -> a.equalsIgnoreCase(cmd))) {
            e.setCancelled(true);
            p.sendMessage(pl.msg("frozen-command"));
        }
    }

    // ----- chat -----

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        if (pl.chatToggle.contains(p.getUniqueId()) && p.hasPermission("staffcore.staffchat")) {
            e.setCancelled(true);
            pl.staffChat(p, e.getMessage());
        }
    }

    // ----- join / quit -----

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        pl.hideVanishedFrom(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (pl.vanished.contains(id)) e.setQuitMessage(null);

        if (inStaff(p)) pl.exitStaff(p, false);
        pl.vanished.remove(id);
        pl.chatToggle.remove(id);

        if (pl.frozen.remove(id)) {
            pl.notifyStaff("staffcore.freeze", pl.msg("frozen-quit", "%player%", p.getName()));
            for (String c : pl.getConfig().getStringList("freeze.quit-commands")) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c.replace("%player%", p.getName()));
            }
        }
    }
}
