package dev.staffcore;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class StaffCommands implements CommandExecutor, TabCompleter {

    private final StaffCore pl;
    private final Map<UUID, Long> reportCooldown = new HashMap<>();

    public StaffCommands(StaffCore pl) {
        this.pl = pl;
    }

    private boolean perm(CommandSender s, String node) {
        if (s.hasPermission(node)) return true;
        s.sendMessage(pl.msg("no-permission"));
        return false;
    }

    private Player player(CommandSender s) {
        if (s instanceof Player p) return p;
        s.sendMessage(pl.msg("player-only"));
        return null;
    }

    private void usage(CommandSender s, String u) {
        s.sendMessage(pl.msg("usage", "%usage%", u));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        switch (c.getName().toLowerCase()) {
            case "staff" -> {
                Player p = player(s);
                if (p == null || !perm(s, "staffcore.staffmode")) return true;
                if (pl.staffMode.contains(p.getUniqueId())) pl.exitStaff(p, true);
                else pl.enterStaff(p);
            }
            case "vanish" -> {
                Player p = player(s);
                if (p == null || !perm(s, "staffcore.vanish")) return true;
                boolean on = !pl.vanished.contains(p.getUniqueId());
                pl.setVanish(p, on);
                p.sendMessage(pl.msg(on ? "vanish-on" : "vanish-off"));
            }
            case "staffchat" -> {
                Player p = player(s);
                if (p == null || !perm(s, "staffcore.staffchat")) return true;
                if (a.length == 0) {
                    boolean on = pl.chatToggle.add(p.getUniqueId());
                    if (!on) pl.chatToggle.remove(p.getUniqueId());
                    p.sendMessage(pl.msg(on ? "staffchat-on" : "staffchat-off"));
                } else {
                    pl.staffChat(p, String.join(" ", a));
                }
            }
            case "freeze" -> {
                if (!perm(s, "staffcore.freeze")) return true;
                if (a.length < 1) { usage(s, "/freeze <player>"); return true; }
                Player t = Bukkit.getPlayerExact(a[0]);
                if (t == null) { s.sendMessage(pl.msg("player-not-found")); return true; }
                pl.toggleFreeze(s, t);
            }
            case "examine" -> {
                Player p = player(s);
                if (p == null || !perm(s, "staffcore.examine")) return true;
                if (a.length < 1) { usage(s, "/examine <player>"); return true; }
                Player t = Bukkit.getPlayerExact(a[0]);
                if (t == null) { s.sendMessage(pl.msg("player-not-found")); return true; }
                pl.openExamine(p, t);
            }
            case "report" -> report(s, a);
            case "reports" -> reports(s, a);
            case "stafflist" -> {
                if (!perm(s, "staffcore.staff")) return true;
                s.sendMessage(pl.msg("stafflist-header"));
                for (Player o : Bukkit.getOnlinePlayers()) {
                    if (!o.hasPermission("staffcore.staff")) continue;
                    boolean hidden = pl.vanished.contains(o.getUniqueId());
                    if (hidden && !s.hasPermission("staffcore.vanish.see")) continue;
                    s.sendMessage(pl.color("&8- &f" + o.getName() + (hidden ? " &7(vanished)" : "")));
                }
            }
            case "staffcore" -> {
                if (!perm(s, "staffcore.admin")) return true;
                if (a.length > 0 && a[0].equalsIgnoreCase("reload")) {
                    pl.reloadConfig();
                    s.sendMessage(pl.msg("reload"));
                } else usage(s, "/staffcore reload");
            }
            default -> { return false; }
        }
        return true;
    }

    private void report(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null || !perm(s, "staffcore.report")) return;
        if (a.length < 2) { usage(s, "/report <player> <reason>"); return; }

        long cd = pl.getConfig().getLong("report-cooldown-seconds", 30) * 1000L;
        long left = reportCooldown.getOrDefault(p.getUniqueId(), 0L) + cd - System.currentTimeMillis();
        if (left > 0) {
            s.sendMessage(pl.msg("report-cooldown", "%seconds%", String.valueOf(left / 1000 + 1)));
            return;
        }
        reportCooldown.put(p.getUniqueId(), System.currentTimeMillis());

        String reason = String.join(" ", Arrays.copyOfRange(a, 1, a.length));
        int id = pl.addReport(p.getName(), a[0], reason);
        p.sendMessage(pl.msg("report-sent", "%id%", String.valueOf(id)));
        pl.notifyStaff("staffcore.reports.notify", pl.msg("report-notify",
                "%id%", String.valueOf(id), "%reporter%", p.getName(), "%target%", a[0], "%reason%", reason));
    }

    private void reports(CommandSender s, String[] a) {
        if (!perm(s, "staffcore.reports")) return;
        String sub = a.length > 0 ? a[0].toLowerCase() : "list";
        switch (sub) {
            case "delete" -> {
                if (a.length < 2) { usage(s, "/reports delete <id>"); return; }
                s.sendMessage(pl.deleteReport(a[1])
                        ? pl.msg("reports-deleted", "%id%", a[1])
                        : pl.msg("reports-not-found"));
            }
            case "clear" -> {
                pl.clearReports();
                s.sendMessage(pl.msg("reports-cleared"));
            }
            default -> {
                ConfigurationSection sec = pl.getReports();
                if (sec == null || sec.getKeys(false).isEmpty()) {
                    s.sendMessage(pl.msg("reports-empty"));
                    return;
                }
                s.sendMessage(pl.msg("reports-header"));
                for (String id : sec.getKeys(false)) {
                    s.sendMessage(pl.msg("reports-line", "%id%", id,
                            "%target%", sec.getString(id + ".target", "?"),
                            "%reporter%", sec.getString(id + ".reporter", "?"),
                            "%reason%", sec.getString(id + ".reason", "?")));
                }
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        String name = c.getName().toLowerCase();
        if (a.length == 1) {
            String start = a[0].toLowerCase();
            List<String> opts = switch (name) {
                case "freeze", "examine", "report" ->
                        Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
                case "reports" -> List.of("list", "delete", "clear");
                case "staffcore" -> List.of("reload");
                default -> List.of();
            };
            return opts.stream().filter(o -> o.toLowerCase().startsWith(start)).collect(Collectors.toList());
        }
        return List.of();
    }
}
