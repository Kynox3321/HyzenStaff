package dev.staffcore;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

public class ExamineHolder implements InventoryHolder {
    public final UUID target;
    private Inventory inventory;

    public ExamineHolder(UUID target) {
        this.target = target;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
